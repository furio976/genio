Genio — Pack prêt à déployer (Frontend static + Backend Express)

CONTENU
- frontend/index.html   -> site statique prêt pour Wegic / Vercel / tout hébergeur statique
- backend/              -> Express API qui appelle OpenAI pour générer des quiz

RAPIDE (deploy minimal)
1) Frontend (Wegic)
   - Upload le dossier 'frontend' (ou seulement index.html) sur Wegic.
   - Tu auras un lien public (ex: https://genio.wegic.app)

2) Backend (Render)
   - Crée un repo GitHub avec le dossier 'backend'.
   - Sur Render: New -> Web Service -> connecte ton repo -> branche main -> start 'npm start'
   - Ajoute la variable d'env: OPENAI_API_KEY
   - Déploie, récupère l'URL publique (ex: https://genio-backend.onrender.com)

3) Connecter frontend au backend
   - Ouvre le site Genio (Wegic) -> clique 'Activer IA' -> colle l'URL backend.
   - Maintenant quand tu lances un quiz, Genio tentera d'utiliser l'IA pour générer des questions.

MONÉTISATION (débuter)
- Utilise Stripe pour vendre abonnements (ex: 4.99€/mois).
- Version freemium: quiz basiques gratuits, fonctionnalités avancées en payant (plans d'étude, export PDF).
- Ajoute page marketing et lien Stripe Checkout (backend nécessaire).

SÉCURITÉ & COÛTS
- Ne jamais publier OPENAI_API_KEY dans GitHub public.
- OpenAI facture à l'usage: surveille les coûts.
- Pour limiter coûts: cache les quiz, limite appels par utilisateur.

SUPPORT
Si tu veux, je peux:
- Générer un ZIP téléchargeable (déjà inclus ici).
- Te donner le script d'installation, ou les commandes précises pour Render/Wegic/Stripe.
- Générer prompts améliorés pour Maths/Français/Histoire.
