const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const OPENAI_KEY = process.env.OPENAI_API_KEY;
if(!OPENAI_KEY) console.warn('OPENAI_API_KEY not set. OpenAI calls will fail.');

async function callOpenAI(prompt, max_tokens=800){
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${OPENAI_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
      messages: [
        {role: 'system', content: 'Tu es un assistant pédagogique pour élèves, clair et patient.'},
        {role: 'user', content: prompt}
      ],
      max_tokens,
      temperature: 0.2
    })
  });
  const data = await res.json();
  if(data.error) throw new Error(JSON.stringify(data.error));
  return data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
}

app.post('/api/generate-quiz', async (req,res)=>{
  try{
    const { subject='Maths', level='premiere', count=5 } = req.body;
    const prompt = `Génère ${count} questions pour la matière ${subject}, niveau ${level}. Pour chaque question, renvoie un objet JSON avec les champs: question (string), choices (array de 4 strings), answer_index (0-3), short_explanation (1-2 phrases). Réponds uniquement par un tableau JSON.`;
    const reply = await callOpenAI(prompt, 1200);
    // try parse
    let json;
    try{ json = JSON.parse(reply); }
    catch(e){
      const start = reply.indexOf('[');
      const end = reply.lastIndexOf(']');
      if(start>=0 && end>=0) json = JSON.parse(reply.slice(start, end+1));
      else throw new Error('Impossible de parser la réponse OpenAI');
    }
    res.json({quiz: json});
  }catch(err){
    console.error(err);
    res.status(500).json({error: err.message});
  }
});

app.post('/api/explain', async (req,res)=>{
  try{
    const { question, student_answer, correct_answer } = req.body;
    const p = `Explique en 2-3 phrases pourquoi "${correct_answer}" est correcte pour la question: ${question}. L'élève a répondu: ${student_answer}.`;
    const reply = await callOpenAI(p, 300);
    res.json({explanation: reply});
  }catch(err){ res.status(500).json({error: err.message}); }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=>console.log('Genio backend listening on port', PORT));
